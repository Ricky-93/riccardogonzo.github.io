---
title: Coherent states from amplitudes and classical factorization
collection: talks
type: Invited seminar
permalink: null
venue: Higgs Centre
date: 2021-06-30
location: Edinburgh, UK
address: Higgs Centre for Theoretical Physics, Edinburgh, UK
---

Invited seminar at Higgs Centre, Edinburgh.
