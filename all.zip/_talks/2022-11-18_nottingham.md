---
title: "Celestial holography on non-trivial backgrounds"
collection: talks
type: "Invited seminar"
permalink: 
venue: "University of Nottingham"
date: 2022-11-18
location: "Nottingham"
---
Invited seminar at University of Nottingham, Nottingham.