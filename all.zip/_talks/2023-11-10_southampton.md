---
title: "Spinning waveforms from classical amplitudes"
collection: talks
type: "Invited seminar"
permalink: 
venue: "STAG centre"
date: 2023-11-10
location: "Southampton, UK"
---
Invited seminar at STAG centre, Southampton.