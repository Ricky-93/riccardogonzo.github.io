---
title: "Scattering and bound waveforms for Kerr black holes"
collection: talks
type: "Invited seminar"
permalink: 
venue: "Tor Vergata"
date: 2023-11-20
location: "Rome, Italy"
---
Invited seminar at Tor Vergata, Rome.