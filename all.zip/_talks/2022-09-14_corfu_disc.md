---
title: "Leader of the discussion session 'Connections between gravity, classical observables"
collection: talks
type: "Invited talk"
permalink: 
venue: "Celestial amplitudes and flat space holography workshop"
date: 2022-09-14
location: "Corfu, Greece"
---
Invited talk at Celestial amplitudes and flat space holography workshop, Corfu.