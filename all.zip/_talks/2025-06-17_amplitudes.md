---
title: "Dirac brackets for classical black hole scattering: from amplitudes to observables"
collection: talks
type: "Invited talk"
permalink: 
venue: "Amplitudes 2025"
date: 2025-06-17
location: "Seoul, South Korea"
---
Invited talk at Amplitudes 2025, Seoul, South Korea. [Link video](https://www.youtube.com/watch?v=r0f0wpcV9S4)