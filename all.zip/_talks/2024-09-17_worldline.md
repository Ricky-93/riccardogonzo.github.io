---
title: "Classical scattering and bound observables from the worldline approach to the"
collection: talks
type: "Invited seminar"
permalink: 
venue: "Worldline Seminars (online)"
date: 2024-09-17
location: "Plymouth, UK"
---
Invited seminar at Worldline Seminars (online), .