---
title: "The structure of intertwiners in the infinite spin representation"
collection: talks
type: "Invited seminar"
permalink: 
venue: "University of Göttingen"
date: 2017-05-29
location: "Göttingen, Germany"
---
Invited seminar at University of Göttingen, Göttingen.