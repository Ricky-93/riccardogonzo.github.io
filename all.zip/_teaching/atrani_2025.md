---
title: 'Analytic Computing in High-Energy and Gravitational Theoretical Physics'
collection: teaching
type: "Lecturer"
permalink: 'https://indico.cern.ch/event/1514553/'
venue: "PhD school in Atrani"
date: 2025-06-01
courseDates: "2025"
location: "Atrani, Italy"
---
Lecturer for the PhD school in Atrani on 'Analytic Computing in High-Energy and Gravitational Theoretical Physics'.
