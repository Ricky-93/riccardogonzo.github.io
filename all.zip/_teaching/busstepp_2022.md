---
title: 'BUSSTEPP 2022'
collection: teaching
type: "Tutor"
permalink: ''
venue: "Imperial College London"
date: 2022-07-01
courseDates: "2 weeks"
location: "London, UK"
---
Tutor for the PhD school BUSSTEPP 2022 (2 weeks).
