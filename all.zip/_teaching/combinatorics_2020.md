---
title: 'Combinatorics (MAU34107)'
collection: teaching
type: "Teaching Assistant"
permalink: ''
venue: "Trinity College Dublin"
date: 2020-01-01
courseDates: "2020"
location: "Dublin, Ireland"
---
Teaching Assistant of Combinatorics class MAU34107.
