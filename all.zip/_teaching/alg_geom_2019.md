---
title: 'Algebraic Geometry (MA341F)'
collection: teaching
type: "Teaching Assistant"
permalink: ''
venue: "Trinity College Dublin"
date: 2019-01-01
courseDates: "2019"
location: "Dublin, Ireland"
---
Teaching Assistant of Algebraic Geometry class MA341F.
