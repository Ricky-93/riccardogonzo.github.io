---
title: 'Differential Calculus (Niels Brock program)'
collection: teaching
type: "Teacher"
permalink: ''
venue: "International School of Billund (ISB)"
date: 2022-03-01
courseDates: "3 months"
location: "ISB, Denmark"
---
Math teacher for differential calculus (Niels Brock program, 3 months).
