---
title: 'Conformal Bootstrap course'
collection: teaching
type: "Tutor"
permalink: ''
venue: "Higgs Centre School of Theoretical Physics"
date: 2022-07-01
courseDates: "1 week"
location: "Edinburgh, UK"
---
Tutor for the Conformal Bootstrap course at the Higgs Centre School of Theoretical Physics (1 week).
